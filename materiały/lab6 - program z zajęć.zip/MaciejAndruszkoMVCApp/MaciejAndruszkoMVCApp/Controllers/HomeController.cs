﻿using MaciejAndruszkoMVCApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MaciejAndruszkoMVCApp.Controllers
{
    public class HomeController : Controller
    {
        private PizzaStoreDbContext context;
        public HomeController()
        {
            context = new PizzaStoreDbContext();
        }
        public ActionResult _Edit(Pizza pizzaToEdit)
        {
            Pizza pizza = context.Pizzas.Find(pizzaToEdit.Id);
            context.Pizzas.Remove(pizza);
            context.Pizzas.Add(pizzaToEdit);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Edit(int id)
        {
            Pizza pizzaToEdit = context.Pizzas.Find(id);
            return View(pizzaToEdit);
        }
        public ActionResult Delete(int id)
        {
            Pizza pizzaToDelete = context.Pizzas.Find(id);
            context.Pizzas.Remove(pizzaToDelete);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Index()
        {
            List<Pizza> pizzas = context.Pizzas.ToList();
            return View(pizzas); // a teraz poprawić w cshtml...
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}
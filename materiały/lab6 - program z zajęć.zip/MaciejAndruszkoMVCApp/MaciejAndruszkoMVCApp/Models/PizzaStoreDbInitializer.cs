﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MaciejAndruszkoMVCApp.Models
{
    public class PizzaStoreDbInitializer : DropCreateDatabaseAlways<PizzaStoreDbContext>
    {
        protected override void Seed(PizzaStoreDbContext context)
        {
            Pizza newPizza = new Pizza() {IsVegetarian = true, Name = "Margarita", Price = 13.50f };
            Pizza newPizza2 = new Pizza() { IsVegetarian = true, Name = "Mafioso", Price = 6.66f };
            Pizza newPizza3 = new Pizza() { IsVegetarian = false, Name = "Prosciutta", Price = 11.50f };
            List<Pizza> pizzas = new List<Pizza>();
            pizzas.Add(newPizza);
            pizzas.Add(newPizza2);
            pizzas.Add(newPizza3);

            context.Pizzas.AddRange(pizzas);

            base.Seed(context);
        }
    }
}
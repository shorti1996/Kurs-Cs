﻿using System.Web;
using System.Web.Mvc;

namespace MaciejAndruszkoMVCApp
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
